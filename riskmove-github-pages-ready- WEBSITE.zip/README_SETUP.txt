RISKMOVE WEBSITE — GITHUB PAGES PACKAGE

This folder is ready to upload to a GitHub repository.

FILES
- index.html — the complete RiskMove one-page website

IMPORTANT
- Keep the filename exactly as index.html.
- Do not place index.html inside another folder when uploading to GitHub.
- The site uses Google Fonts and public JavaScript libraries, so visitors need an internet connection.
- Before changing DNS, preserve all MX and TXT records used by cmelendez@riskmove.us.

Suggested repository name:
riskmove-site
